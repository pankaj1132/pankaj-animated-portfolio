import type { Metadata } from 'next';
import './globals.css';
import './additions.css';
export const metadata: Metadata = {title:'Pankaj Saini — Full Stack Developer',description:'Full stack developer based in New Delhi. Building thoughtful web experiences with React, Next.js, Node.js and Salesforce.'};
export default function Layout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}

