'use client';

import { motion } from 'motion/react';

// The supplied portrait is displayed without altering the original image.
const portrait = '/portrait.png';

export default function PortraitCard() {
  return (
    <motion.figure className="portrait-card" whileHover={{ rotate: 0, y: -8 }} transition={{ type: 'spring', stiffness: 180, damping: 16 }}>
      <div className="portrait-image">
        <img src={portrait} alt="Portrait of Pankaj Saini" width="240" height="280" />
        <span className="portrait-scan" aria-hidden="true" />
        <span className="portrait-cross top-left" aria-hidden="true">+</span>
        <span className="portrait-cross bottom-right" aria-hidden="true">+</span>
        <span className="portrait-label">PANKAJ SAINI / NEW DELHI</span>
      </div>
      <figcaption><strong>Pankaj Saini</strong><span>DEVELOPER · BUILDER <b>↗</b></span></figcaption>
    </motion.figure>
  );
}

