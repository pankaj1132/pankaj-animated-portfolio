'use client';

import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

export default function MotionEffects() {
  const progress = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add('(prefers-reduced-motion: no-preference)', () => {
      gsap.to(progress.current, {
        scaleX: 1,
        ease: 'none',
        scrollTrigger: { start: 0, end: 'max', scrub: true },
      });
      gsap.to('.sculpture', {
        y: 90,
        rotation: 12,
        ease: 'none',
        scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: 1 },
      });
      gsap.from('.mock-chart i', {
        scaleY: 0,
        transformOrigin: 'bottom',
        stagger: 0.09,
        duration: 1.2,
        ease: 'elastic.out(1, 0.65)',
        scrollTrigger: { trigger: '.axion', start: 'top 80%' },
      });
      gsap.from('.portrait-card', {
        y: 45, rotation: 8, opacity: 0, duration: 1.3, delay: 0.35, ease: 'power3.out',
      });
      gsap.from('.featured-credential', {
        y: 65, opacity: 0, duration: 1,
        scrollTrigger: { trigger: '.featured-credential', start: 'top 88%' },
      });
      gsap.from('.learning-card', {
        y: 55, opacity: 0, stagger: 0.15, duration: 0.8,
        scrollTrigger: { trigger: '.learning-grid', start: 'top 90%' },
      });
      gsap.to('.credential-seal', {
        rotation: 12, ease: 'none',
        scrollTrigger: { trigger: '.featured-credential', start: 'top bottom', end: 'bottom top', scrub: 1 },
      });
      gsap.utils.toArray<HTMLElement>('.timeline-row').forEach((row) => {
        gsap.from(row, {
          borderTopColor: '#b9f563',
          duration: 1.5,
          scrollTrigger: { trigger: row, start: 'top 75%', toggleActions: 'play none none reverse' },
        });
      });
    });

    media.add('(hover: hover) and (prefers-reduced-motion: no-preference)', () => {
      const cleanups: (() => void)[] = [];
      document.querySelectorAll<HTMLElement>('.project-visual').forEach((card) => {
        const preview = card.querySelector<HTMLElement>('.mockup, .code-window');
        if (!preview) return;
        const rotateX = gsap.quickTo(preview, 'rotationX', { duration: 0.6, ease: 'power3.out' });
        const rotateY = gsap.quickTo(preview, 'rotationY', { duration: 0.6, ease: 'power3.out' });
        const onMove = (event: PointerEvent) => {
          const bounds = card.getBoundingClientRect();
          const x = (event.clientX - bounds.left) / bounds.width;
          const y = (event.clientY - bounds.top) / bounds.height;
          rotateX((0.5 - y) * 20);
          rotateY((x - 0.5) * 20);
          card.style.setProperty('--pointer-x', `${x * 100}%`);
          card.style.setProperty('--pointer-y', `${y * 100}%`);
        };
        const onLeave = () => { rotateX(0); rotateY(0); };
        card.addEventListener('pointermove', onMove);
        card.addEventListener('pointerleave', onLeave);
        cleanups.push(() => {
          card.removeEventListener('pointermove', onMove);
          card.removeEventListener('pointerleave', onLeave);
        });
      });
      document.querySelectorAll<HTMLElement>('.primary, .talk').forEach((button) => {
        const x = gsap.quickTo(button, 'x', { duration: 0.5, ease: 'power3.out' });
        const y = gsap.quickTo(button, 'y', { duration: 0.5, ease: 'power3.out' });
        const onMove = (event: PointerEvent) => {
          const bounds = button.getBoundingClientRect();
          x((event.clientX - bounds.left - bounds.width / 2) * 0.15);
          y((event.clientY - bounds.top - bounds.height / 2) * 0.2);
        };
        const onLeave = () => { x(0); y(0); };
        button.addEventListener('pointermove', onMove);
        button.addEventListener('pointerleave', onLeave);
        cleanups.push(() => {
          button.removeEventListener('pointermove', onMove);
          button.removeEventListener('pointerleave', onLeave);
        });
      });
      return () => cleanups.forEach((cleanup) => cleanup());
    });
    return () => media.revert();
  }, []);

  return <div ref={progress} className="scroll-progress" aria-hidden="true" />;
}
