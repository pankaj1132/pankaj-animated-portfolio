'use client';

import { motion } from 'motion/react';
import { Award, Code2, Layers, Sparkles, ArrowUpRight } from 'lucide-react';

const milestones = [
  { issuer: 'CODING BLOCKS', title: 'Data Structures & Algorithms', label: 'TECHNICAL TRAINING', description: 'C++ fundamentals, data structures and algorithmic problem-solving.', icon: Code2 },
  { issuer: 'QSPIDERS', title: 'Full-Stack Development', label: 'DEVELOPMENT TRAINING', description: 'Frontend, backend, databases and RESTful API development.', icon: Layers },
  { issuer: 'GOOGLE ARCADE', title: 'Learning through exploration', label: 'PROGRAM PARTICIPATION', description: 'Completed program milestones and earned participation rewards.', icon: Sparkles },
];

export default function Certifications() {
  return (
    <section id="certifications" className="section certifications">
      <div className="section-heading reveal">
        <span className="eyebrow">04 / CREDENTIALS & CURIOSITY</span>
        <h2>Always learning.<br/><em>Always leveling up.</em></h2>
        <p>Professional certification.<br/>Practical training. Persistent curiosity.</p>
      </div>
      <motion.article className="featured-credential" whileHover={{ y: -5 }}>
        <div className="credential-art" aria-hidden="true">
          <div className="credential-orbit orbit-one"/><div className="credential-orbit orbit-two"/>
          <div className="credential-seal"><Award size={55} strokeWidth={1}/><span>PLATFORM<br/>DEVELOPER I</span></div>
          <span className="seal-caption">SALESFORCE CERTIFIED</span>
        </div>
        <div className="credential-copy">
          <span className="eyebrow">SALESFORCE / PROFESSIONAL CERTIFICATION</span>
          <h3>Platform Developer I</h3>
          <p>Building on the Salesforce platform with Apex, Triggers and Lightning Web Components. Sales Cloud and Data Cloud are also listed in my resume.</p>
          <div className="tags"><span>Apex</span><span>Triggers</span><span>Lightning Web Components</span></div>
          <a className="text-link" href="https://drive.google.com/file/d/1D6igK8hRxIuipPX5pWjZ5uqSrgCsQt-B/view?usp=sharing" target="_blank" rel="noreferrer">View certificate <ArrowUpRight size={18}/></a>
        </div>
        <span className="credential-number" aria-hidden="true">01</span>
      </motion.article>
      <div className="learning-grid">
        {milestones.map(({ issuer, title, label, description, icon: Icon }, index) => (
          <motion.article className="learning-card" key={issuer} whileHover={{ y: -7 }} transition={{ type: 'spring', stiffness: 220, damping: 22 }}>
            <div className="learning-top"><Icon size={24} strokeWidth={1.3}/><span>0{index + 2}</span></div>
            <span className="learning-issuer">{issuer}</span><h3>{title}</h3><p>{description}</p><span className="learning-label">{label}</span>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
