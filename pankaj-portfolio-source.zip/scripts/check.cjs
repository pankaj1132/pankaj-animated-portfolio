const assert = require('node:assert/strict');
const fs = require('node:fs');
const html = fs.readFileSync('out/index.html','utf8');
for (const id of ['work','about','experience','certifications','contact']) assert(html.includes(`id="${id}"`), `Missing ${id}`);
for (const target of ['https://github.com/pankaj1132/AI-Career_coach','https://github.com/pankaj1132/Talvex-code-runner','mailto:pankaj17469@gmail.com','https://wa.me/918851821053']) assert(html.includes(target), `Missing ${target}`);
for (const resume of ['full-stack','salesforce']) assert(fs.statSync(`out/resumes/${resume}.pdf`).size>1000);
assert(html.includes('COMING SOON'), 'Missing social placeholders');
console.log('Export content, contact links, project links and both resume downloads verified.');

assert(fs.existsSync('out/portrait.png'), 'Portrait asset missing');
assert(html.includes('1D6igK8hRxIuipPX5pWjZ5uqSrgCsQt-B'), 'Certificate URL missing');


